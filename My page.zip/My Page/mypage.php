<?php

$servername = "sql106.infinityfree.com";
$username = "if0_42361813";
$password = "13W5lqPdGJRv";
$dbname = "if0_42361813_mydatabase";

// Get data from the form
$name = $_GET['name'] ?? '';
$age = $_GET['age'] ?? '';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert new record only if name and age were entered
if ($name != "" && $age != "") {

    $sql = "INSERT INTO user (Name, Age, Status)
            VALUES ('$name', '$age', 0)";

    if ($conn->query($sql) === TRUE) {
        echo "<p>New record created successfully.</p>";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Get all records
$sql = "SELECT ID, Name, Age, Status FROM user";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>

    <title>User Information</title>

    <style>

        table {
            border-collapse: collapse;
            width: 70%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        button {
            padding: 6px 15px;
            cursor: pointer;
        }

    </style>

</head>

<body>

<h2>User Information</h2>

<!-- Form -->
<form action="mypage.php" method="get">

    <label for="name">Name:</label><br>

    <input type="text"
           id="name"
           name="name"
           placeholder="Write Your Name"
           required>

    <br><br>

    <label for="age">Age:</label><br>

    <input type="text"
           id="age"
           name="age"
           placeholder="Write Your Age"
           required>

    <br><br>

    <input type="submit" value="Submit">

</form>


<!-- Users Table -->

<h2>All Users</h2>

<table>

    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

<?php

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $id = $row["ID"];
        $status = $row["Status"];

        echo "<tr>";

        echo "<td>" . $row["ID"] . "</td>";

        echo "<td>" . $row["Name"] . "</td>";

        echo "<td>" . $row["Age"] . "</td>";

        // Status
        echo "<td id='status-$id'>" . $status . "</td>";

        // Toggle button
        echo "<td>";

        echo "<button onclick='toggleStatus($id)'>Toggle</button>";

        echo "</td>";

        echo "</tr>";
    }

} else {

    echo "<tr>";
    echo "<td colspan='5'>No records found</td>";
    echo "</tr>";

}

?>

</table>


<script>

function toggleStatus(id) {

    // Send request to toggle.php
    fetch("toggle.php?id=" + id)

    .then(response => response.text())

    .then(newStatus => {

        // Update the status displayed on the page
        document.getElementById("status-" + id).innerText = newStatus;

    })

    .catch(error => {

        console.log("Error:", error);

    });

}

</script>


</body>
</html>

<?php

$conn->close();

?>