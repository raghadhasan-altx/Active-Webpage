<?php

$servername = "sql106.infinityfree.com";
$username = "if0_42361813";
$password = "13W5lqPdGJRv";
$dbname = "if0_42361813_mydatabase";

// Get ID from the request
$id = $_GET['id'] ?? '';

if ($id == '') {
    die("Invalid ID");
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get current status
$sql = "SELECT Status FROM user WHERE ID = $id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();

    $currentStatus = $row["Status"];

    // Toggle status
    if ($currentStatus == 0) {
        $newStatus = 1;
    } else {
        $newStatus = 0;
    }

    // Update database
    $sql = "UPDATE user
            SET Status = $newStatus
            WHERE ID = $id";

    if ($conn->query($sql) === TRUE) {

        // Send the new status back to JavaScript
        echo $newStatus;

    } else {

        echo "Error";

    }

} else {

    echo "User not found";

}

$conn->close();

?>